﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace SampleExternalAppToExorLive
{
	public partial class MainForm : Form
	{
		//// The ApplicationKey and ApplicationSecret identifies the application that shall have access to ExorLive.
		//// ExorLive is configured the know this application and what it is allowed to do.
		//// The application is connected to one account (one organization) in ExorLive.
		//// ExorLive API Support will issue you the correct information for the 4 definitions below.
		//private const String ApplicationKey = "www.mysamplesystem.com";
		//private const string ApplicationSecret = "<we send you an applicationsecret by email upon request>";
		//readonly string _requesterDomain = HttpUtility.UrlEncode("http://www.mysamplesystem.com/");
		//private const int AdminUserId = 9999999; // User id of an admin user, to be able to look up other users.

		//readonly string _scope = HttpUtility.UrlEncode("read_profile read_workout read_master write_workout write_profile read_calendar read_contact admin_user create_session configure write_calendar write_contact partner");
		readonly string _scope = HttpUtility.UrlEncode("read_profile read_workout read_master write_workout write_profile read_calendar read_contact admin_user create_session configure write_calendar write_contact");


		//private const String ApplicationKey = "hemit.it.localhost";
		//private const string ApplicationSecret = "7f401b12345c3c3bffd35e18596a1234";
		//readonly string _requesterDomain = HttpUtility.UrlEncode("http://localhost/");
		//private const int AdminUserId = 1406672; // User id of an admin user, to be able to look up other users.

		//// The settings below must be exactly as defined here to make the API work.
		private const String ApplicationKey = "testkey";
		private const string ApplicationSecret = "testsecret";
		readonly string _requesterDomain = HttpUtility.UrlEncode("http://testkey/");
		private const int AdminUserId = 1; // User id of an admin user, to be able to look up other users.
		private const string Authdomain = "http://localhost:50006";
		private const string ExorLiveAppDomain = "http://localhost:50000";

		// The settings below must be exactly as defined here to make the API work.
		//private const String ApplicationKey = "local.exorlive.com";
		//private const string ApplicationSecret = "secrettest";
		//readonly string _requesterDomain = HttpUtility.UrlEncode("http://localhost:8081/");
		//private const int AdminUserId = 1; // User id of an admin user, to be able to look up other users.
		//private const string Authdomain = "http://auth-int.exorlive.com";
		//private const string ExorLiveAppDomain = "http://int.exorlive.com";

		// mindoktor.se - INT
		//private const String ApplicationKey = "mindoktor";
		//private const string ApplicationSecret = "c4X8hWnPCeQyXR6mYdKnzb98zRTe5W8N";
		//readonly string _requesterDomain = HttpUtility.UrlEncode("http://mindoktor.se/");
		//private const int AdminUserId = 547818; // User id of an admin user, to be able to look up other users.
		//private const string Authdomain = "https://auth-int.exorlive.com";
		//private const string ExorLiveAppDomain = "https://int.exorlive.com";

		/////// mindoktor.se - localhost - INT
		//private const String ApplicationKey = "localhost.mindoktor";
		//private const string ApplicationSecret = "c4X8hWnPCeQyXR6mYdKnzb98zRTe5W8N";
		//readonly string _requesterDomain = HttpUtility.UrlEncode("http://localhost:9110/");
		//private const int AdminUserId = 547818; // User id of an admin user, to be able to look up other users.
		//private const string Authdomain = "https://auth-int.exorlive.com";
		//private const string ExorLiveAppDomain = "https://int.exorlive.com";

		// mindoktor.se - PRODUKSJON
		//private const String ApplicationKey = "mindoktor.se";
		//private const string ApplicationSecret = "0dc7ebb5986ea3ff9069f9a9d7ecae04";
		//readonly string _requesterDomain = HttpUtility.UrlEncode("http://mindoktor.se/");
		//private const int AdminUserId = 1433016; // User id of an admin user, to be able to look up other users.
		//private const string Authdomain = "https://auth.exorlive.com";
		//private const string ExorLiveAppDomain = "https://exorlive.com";

		// landstinget.se - PRODUKSJON
		//private const String ApplicationKey = "test.landstinget.dalarna";
		//private const string ApplicationSecret = "846beadadf07423fdd416237e2930be0";
		//readonly string _requesterDomain = HttpUtility.UrlEncode("http://ltdalarna.se");
		//private const int AdminUserId = 1982778; // User id of an admin user, to be able to look up other users.
		//private const string Authdomain = "https://auth.exorlive.com";
		//private const string ExorLiveAppDomain = "https://exorlive.com";

		//// fitnessworld.dk - PRODUKSJON - TEST
		//private const String ApplicationKey = "test.dk.fitnessworld.com";
		//private const string ApplicationSecret = "58f1b95068b1b3491bde41f06b116c3c";
		//readonly string _requesterDomain = HttpUtility.UrlEncode("http://fitnessworld.com/");
		//private const int AdminUserId = 2064962; // User id of an admin user, to be able to look up other users.
		//private const string Authdomain = "https://auth.exorlive.com";
		//private const string ExorLiveAppDomain = "https://exorlive.com";



		///////// TEST1
		//private const String ApplicationKey = "local.exor.no";
		//private const string ApplicationSecret = "secrettest";
		//readonly string _requesterDomain = HttpUtility.UrlEncode("http://localhost:8082/");
		//private const int AdminUserId = 1098288; // User id of an admin user, to be able to look up other users.
		//private const string Authdomain = "http://auth.test.exorlive.com";
		//private const string ExorLiveAppDomain = "http://test.exorlive.com";

		// The settings below must be exactly as defined here to make the API work.
		//readonly string _scope = HttpUtility.UrlEncode("read_profile read_workout read_master write_workout write_profile read_calendar read_contact admin_user create_session configure write_calendar write_contact");
		//private const string Authdomain = "https://auth.exorlive.com";
		//private const string ExorLiveAppDomain = "https://exorlive.com";

		private int _exorLiveInstructorUserId; // The ExorLive userId of a user in ExorLive (within the applications organization) that has access to administrate users (Administrator or Instructor role).

		public MainForm()
		{
			_exorLiveInstructorUserId = AdminUserId;
			InitializeComponent();
			txtInstructorUserId.Text = _exorLiveInstructorUserId.ToString();

			// Example data for a contact/client/patient.
			txtCustomId.Text = @"231";
			txtFirstname.Text = @"Arnold";
			txtLastname.Text = @"Schwarzenegger";
			txtEmail.Text = @"arnold@exorlive.com";
		}

		private void btnCopyWorkoutToUser_Click(object sender, EventArgs e)
		{
			Output("");
			int instructorUserId;
			if (int.TryParse(txtInstructorUserId.Text, out instructorUserId) && instructorUserId > 0)
			{
				string accesstoken = GetAccessToken(instructorUserId);

				// We know the Custom-Id, so we ask ExorLive for the corresponding ExorLive userId.
				int contactUserId = GetExorLiveUserIdFromCustomId(txtCustomId.Text, false);
				if (contactUserId > 0)
				{
					int workoutId;
					if (int.TryParse(txtWorkoutId.Text, out workoutId))
					{
						string response = MakeCopyOfWorkout(accesstoken, workoutId, contactUserId);

						// Format JSON to make it more readable (this is slow...)
						string formattedjson = MakeJson(DeserializeJson<dynamic>(response));
						Output(formattedjson);
					}
					else
					{
						Output("Specify workout id");
					}
				}
				else
				{
					Output("Specify user by custom id");
				}
			}
			else
			{
				Output("Specify instructor user id");
			}
		}

		private void btnGetWorkouts_Click(object sender, EventArgs e)
		{
			int instructorUserId;
			if (int.TryParse(txtInstructorUserId.Text, out instructorUserId) && instructorUserId > 0)
			{
				string accesstoken = GetAccessToken(instructorUserId);
				string response = QueryWorkouts(accesstoken);

				// Format JSON to make it more readable (this is slow...)
				string formattedjson = MakeJson(DeserializeJson<dynamic>(response));
				Output(formattedjson);
			}
		}

		private void btnGetUsers_Click(object sender, EventArgs e)
		{
			int instructorUserId;
			if (int.TryParse(txtInstructorUserId.Text, out instructorUserId) && instructorUserId > 0)
			{
				string accesstoken = GetAccessToken(instructorUserId);
				if (accesstoken != null)
				{
					string response = GetListOfUsers(accesstoken);

					// Format JSON to make it more readable (this is slow...)
					string formattedjson = MakeJson(DeserializeJson<dynamic>(response));
					Output(formattedjson);
				}
			}
		}

		private void btnLookupUser_Click(object sender, EventArgs e)
		{
			int instructorUserId;
			if (int.TryParse(txtInstructorUserId.Text, out instructorUserId) && instructorUserId > 0)
			{
				if (!string.IsNullOrWhiteSpace(txtCustomId.Text))
				{
					// We know the Custom-Id, so we ask ExorLive for the corresponding ExorLive userId.
					int contactUserId = GetExorLiveUserIdFromCustomId(txtCustomId.Text, false);

					if (contactUserId > 0)
					{
						string response = GetPersonDetails("", contactUserId);
						string formattedjson = MakeJson(DeserializeJson<dynamic>(response));
						Output(formattedjson);
					}
					else
					{
						Output("Found no user in ExorLive with custom id ' " + txtCustomId.Text + "'");
					}
				}
				else
				{
					Output("Please enter an id to look up");
				}
			}
		}

		private void btnSetDisabled_Click(object sender, EventArgs e)
		{
			int userId;
			if (int.TryParse(txtUserIdForDisable.Text, out userId))
			{
				int instructorUserId;
				if (int.TryParse(txtInstructorUserId.Text, out instructorUserId) && instructorUserId > 0)
				{
					string accesstoken = GetAccessToken(instructorUserId);
					if (accesstoken != null)
					{
						bool disable = chkDisabled.Checked;
						string response = SetUserDisabled(accesstoken, userId, disable);

						// Format JSON to make it more readable (this is slow...)
						string formattedjson = MakeJson(DeserializeJson<dynamic>(response));
						Output(formattedjson);
					}
				}
			}
		}

		private string SetUserDisabled(string accessToken, int userId, bool disable)
		{
			if (string.IsNullOrWhiteSpace(accessToken))
			{
				accessToken = GetAccessToken(int.Parse(txtInstructorUserId.Text));
			}

			var data = new Dictionary<string, string>
			{
				{"personId", userId.ToString()},
				{"disabled", disable?"1":"0"}
			};

			var json = MakeJson(data);
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/SetUserDisabled";
			var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call

			// The result is a JSON string
			return response;
		}

		private void btnDepartments_Click(object sender, EventArgs e)
		{
			int instructorUserId;
			if (int.TryParse(txtInstructorUserId.Text, out instructorUserId) && instructorUserId > 0)
			{
				string accesstoken = GetAccessToken(instructorUserId);
				if (accesstoken != null)
				{
					string response = GetDepartments(accesstoken);

					// Format JSON to make it more readable (this is slow...)
					string formattedjson = MakeJson(DeserializeJson<dynamic>(response));
					Output(formattedjson);

				}
			}

		}


		private void btnOpenExorLive_Click(object sender, EventArgs e)
		{
			int instructorUserId;
			if (int.TryParse(txtInstructorUserId.Text, out instructorUserId) && instructorUserId > 0)
			{
				if (!string.IsNullOrWhiteSpace(txtCustomId.Text))
				{
					// We know the Custom-Id, so we ask ExorLive for the corresponding ExorLive userId.
					int contactUserId = GetExorLiveUserIdFromCustomId(txtCustomId.Text, true);

					// Open ExorLive with this user logged in.
					if (contactUserId > 0)
					{
						OpenExorLiveWithActiveContact(instructorUserId, contactUserId);
					}
					else
					{
						Output("Failed to find/create user in ExorLive with custom id ' " + txtCustomId.Text + "'");
					}
				}
				else
				{
					Output("Please enter an id to look up");
				}
			}
		}

		private void btnOpenPersonal_Click(object sender, EventArgs e)
		{
			int instructorUserId;
			if (int.TryParse(txtInstructorUserId.Text, out instructorUserId) && instructorUserId > 0)
			{
				OpenExorLivePersonal(instructorUserId);
			}
			else
			{
				Output("Please enter an id to look up");
			}
		}

		private void Output(string text)
		{
			txtOutput.Text = text;
		}
		private void AppendOutput(string text)
		{
			txtOutput.Text += Environment.NewLine + text;
		}


		/// <summary>
		/// Will query ExorLive for a user with the given Custom Id.
		/// Will create the user in ExorLive if not there already.
		/// </summary>
		/// <returns></returns>
		private int GetExorLiveUserIdFromCustomId(string customId, bool create)
		{
			if (!string.IsNullOrWhiteSpace(customId))
			{
				// Must authenticate as a valid administrator/instructor in the ExorLive Organization that this application has access to.
				string accessToken = GetAccessToken(_exorLiveInstructorUserId); // Authenticate as this user

				// Query as the admin user, ask for a user with the given custom Id (Id used in the External Application,  called customId in ExorLive)
				var data = new Dictionary<string, string>
				{
					{"customId", customId}
				};

				var json = MakeJson(data);
				var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/ResolveCustomId";
				var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call

				// Parse the result.
				var userIdHolder = JsonConvert.DeserializeObject<dynamic>(response); // Deserialize the JSON to a dynamic object
				int userId = (int)userIdHolder.d.Data;
				if (userId == 0 && create)
				{
					// The user was not found, so we create it.
					userId = CreateUserInExorLive(accessToken);
				}
				return userId;
			}
			return 0;
		}


		/// <summary>
		/// Shows how the make the call to create a user/contact in ExorLive.
		/// 
		/// Note: A 'user' may be an instructor/administrator in ExorLive. 
		///       A 'user' may also be a contact/patent/client. We call it a contact and it may or may not have its own login. That's why we call it a 'user'.
		///       A 'contact' with login will have access to ExorLive Personal to see workouts issued and to record activities.
		/// </summary>
		/// <param name="accessToken"></param>
		/// <returns></returns>
		private int CreateUserInExorLive(string accessToken)
		{
			var data = new
			{
				person = new
				{
					Id = 0,                           // Set to 0 to create this user in ExorLive. Set to a valid userId to update an existing user.
					CustomId = txtCustomId.Text,
					Firstname = txtFirstname.Text,
					Lastname = txtLastname.Text,
					Email = txtEmail.Text,
					IsActivated = 1,                   // Must be set to 1 to create and immediately activate this user

					Address = "",
					Location = "",
					Zipcode = "",

					Comment = "User created by My Journal Program",  // Comment about this clients training.
					Companyname = "",           // The employer of this client.
					CultureString = "nb-NO",    // The 5-letter code for the language. Leave blank for the default language in the browser. Supported languages are : nb-NO, sv-SE, da-DK, fi-FI, en-US
					DateOfBirth = "1947-07-30", // Leave blank, or make sure it is a valid date in the format YYYY-mm-DD
					Type = 16,                  // Leave '16', to make this user a 'client'. Set to 8 to make it an instructor.
					DepartmentId = 0,           // Use if the organization has sub-departments.
					Description = "A test-user",// Who is this person
					Height = 0,               // integer. Height in cm.
					Phone1 = "",              // Home phone number
					Phone2 = "",              // Mobile phonenumber
					Phone3 = "",              // Work phone number
					PrimaryContact = _exorLiveInstructorUserId, // The user id of the instructor that 'owns' this contact. May be the logged in instructor, or another user id.
					Sex = 1,                  // 0: unknown, 1: male, 2: female
					Web = "",                 // a URL, if the user has a webpage.
					Weight = 0,               // Weight of the user, in KG.
					WeightGoal = 0            // The Weight goal, if the goal of the client is to reduce weight.
				}
			};
			var json = MakeJson(data);
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/SetPersonDetails"; // This call may also be used to update an existing user
			var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call

			// Parse the result.
			var userIdHolder = JsonConvert.DeserializeObject<dynamic>(response); // Deserialize the JSON to a dynamic object
			int userId = (int)userIdHolder.d.Data;
			return userId;
		}


		/// <summary>
		/// En example of another useful method in the API
		/// </summary>
		/// <param name="accessToken"></param>
		/// <param name="userId"></param>
		private string GetPersonDetails(string accessToken, int userId)
		{
			if (string.IsNullOrWhiteSpace(accessToken))
			{
				accessToken = GetAccessToken(int.Parse(txtInstructorUserId.Text));
			}

			var data = new Dictionary<string, string>
			{
				{"personId", userId.ToString()}
			};

			var json = MakeJson(data);
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/GetPersonDetails";
			var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call

			// The result is a JSON string
			return response;
		}

		private void SetCustomId(string accessToken, int userId, string customId)
		{
			if (string.IsNullOrWhiteSpace(accessToken))
			{
				accessToken = GetAccessToken(int.Parse(txtInstructorUserId.Text));
			}

			var data = new Dictionary<string, string>
			{
				{"personId", userId.ToString()},
				{"customId", customId}
			};
			var json = MakeJson(data);
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/SetCustomId";
			var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call
		}

		private string QueryWorkouts(string accessToken)
		{
			if (string.IsNullOrWhiteSpace(accessToken))
			{
				accessToken = GetAccessToken(int.Parse(txtInstructorUserId.Text));
			}
			//Location = "1",
			//LocationId = txtInstructorUserId.Text,
			var data = new
			{
				query = new
				{
					Location = "0",
					LocationId = "0",
					Query = "",
					Nested = "1",
					Start = "0",
					Length = "1000",
					OnlyTemplates = "1"
				}
			};

			var json = MakeJson(data);
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Workouts.svc/QueryWorkouts";
			var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call
																								   // The result is a JSON string
			return response;
		}

		private string MakeCopyOfWorkout(string accessToken, int workoutId, int targetUserId)
		{
			if (string.IsNullOrWhiteSpace(accessToken))
			{
				accessToken = GetAccessToken(int.Parse(txtInstructorUserId.Text));
			}
			var data = new Dictionary<string, string>
			{
				{"workoutId", workoutId.ToString()},
				{"userId", targetUserId.ToString()}
			};
			var json = MakeJson(data);
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Workouts.svc/CopyWorkoutToUser";
			var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call
																								   // The result is a JSON string
			try
			{
				var responseAsDynamic = JsonConvert.DeserializeObject<dynamic>(response);
				int newWorkoutId = (int)responseAsDynamic.d.Data;
				Output("New WorkoutId=" + newWorkoutId);
			}
			catch (Exception ex)
			{
				Output(ex.Message + Environment.NewLine + response);
				return null;
			}
			return response;
		}

		private string GetListOfUsers(string accessToken)
		{
			if (string.IsNullOrWhiteSpace(accessToken))
			{
				accessToken = GetAccessToken(int.Parse(txtInstructorUserId.Text));
			}
			var data = new Dictionary<string, string>
			{
				{"unitId", "0"},
				{"role", "8"},
				{"page", "0"},
				{"pagesize", "1000"}
			};
			var json = MakeJson(data);
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/GetListOfUsers";
			var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call
																								   // The result is a JSON string
			return response;
		}

		private string GetDepartments(string accessToken)
		{
			if (string.IsNullOrWhiteSpace(accessToken))
			{
				accessToken = GetAccessToken(int.Parse(txtInstructorUserId.Text));
			}
			var data = new Dictionary<string, string>
			{
			};
			var json = MakeJson(data);
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Core.svc/GetListOfDepartments";
			var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call
																								   // The result is a JSON string
			return response;
		}

		/// <summary>
		/// Will open exorlive with the specified user logged in.
		/// If the user has role "Instructor", full Exorlive web-application is opened.
		/// (If the logged in user only has role "ReducedUser" (which is the same as a contact with login), ExorLive Personal is opened.)
		/// 
		/// This will only work for a user in the organization that the ApplicationKey / ApplicationSecret is authorized for.
		/// </summary>
		/// <param name="instructorUserId">the exorlive user id of the user to be logged in</param>
		/// <param name="contactUserId">the exorlive user id of the contact to be selected in the GUI</param>
		private void OpenExorLiveWithActiveContact(int instructorUserId, int contactUserId)
		{
			string accessToken = GetAccessToken(instructorUserId);

			// Append the access_token to the URL of the authorization page. This will automatically login the user.
			// 'selectedPersonId' is the parameter to automatically select a contact.
			// '#Workouts' is used to automatically activate the workouts tab.
			string redirecturi = string.Format("{0}/app/?selectedPersonId={1}#Workouts", ExorLiveAppDomain, contactUserId);
			var uri = String.Format("{0}/?access_token={1}&redirect={2}", Authdomain, accessToken, HttpUtility.UrlEncode(redirecturi));
			Process.Start(uri);
		}

		/// <summary>
		/// Will open exorlive personal with the specified user logged in.
		/// This will only work for a user in the organization that the ApplicationKey / ApplicationSecret is authorized for.
		/// </summary>
		private void OpenExorLivePersonal(int contactUserId)
		{
			string accessToken = GetAccessToken(contactUserId);

			// Append the access_token to the URL of the authorization page. This will automatically login the user.
			// Tell the authorization page to redirect to the Exorlive Personal page after logged in.
			const string redirecturi = "https://exorlive.com/m/";
			var uri = String.Format("{0}/?access_token={1}&redirect={2}", Authdomain, accessToken, HttpUtility.UrlEncode(redirecturi));
			Process.Start(uri);
		}


		private string GetAccessToken(int userId)
		{
			// This uses OAuth 2.0 conventions.

			// First get the authcode for the given user
			var data = new Dictionary<string, string>
			{
				{"user_id", userId.ToString(CultureInfo.InvariantCulture)},
				{"response_type", "code"},
				{"client_id", ApplicationKey},
				{"client_secret", ApplicationSecret},
				{"redirect_uri", _requesterDomain},
				{"scope", _scope}
			};
			string parameters = MakeQueryParameters(data);
			var authorizeUri = string.Format("{0}/Providers/OAuth/Authorize.aspx", Authdomain);
			string response = SendHttpRequest("GET", authorizeUri, "application/x-www-form-urlencoded", parameters, null);
			string code = "";
			try
			{
				var codeResponseAsDynamic = JsonConvert.DeserializeObject<dynamic>(response);
				code = codeResponseAsDynamic.code;
			}
			catch (Exception ex)
			{
				Output(ex.Message + Environment.NewLine + response);
				return null;
			}

			// Given the authcode, get the access_token.
			data = new Dictionary<string, string>
			{
				{"grant_type", "authorization_code"},
				{"client_id", ApplicationKey},
				{"client_secret", ApplicationSecret},
				{"code", code},
				{"redirect_uri", _requesterDomain}
			};
			string json = MakeQueryParameters(data);
			var tokenUrl = String.Format("{0}/Providers/OAuth/Token.ashx", Authdomain);
			var response2 = SendHttpRequest("POST", tokenUrl, "application/x-www-form-urlencoded", json, null);

			//string json = MakeJson(data);
			//var tokenUrl = String.Format("{0}/Providers/OAuth/Token.ashx", Authdomain);
			//var response2 = SendHttpRequest("POST", tokenUrl, "application/json", json, null);

			try
			{
				var tokenResponseAsDynamic = JsonConvert.DeserializeObject<dynamic>(response2);
				string token = tokenResponseAsDynamic.access_token;
				// TODO: Extract expire-time and refresh_token from token response.
				// TODO: Code to handle that a token expires and is renewed with the refresh_token.
				return token;
			}
			catch (Exception ex)
			{
				Output(ex.Message + Environment.NewLine + response2);
				return null;
			}
		}



		#region http convenience methods

		private readonly JsonSerializerSettings _jsonSettings = new JsonSerializerSettings
		{
			Formatting = Formatting.Indented, // for readability, change to None for compactness
			ContractResolver = new DefaultContractResolver(),
			DateTimeZoneHandling = DateTimeZoneHandling.Utc
		};

		private string MakeQueryParameters(Dictionary<string, string> dict)
		{
			var uris = (dict.Select(x => String.Format("{0}={1}", x.Key, x.Value))).ToList();
			return string.Join("&", uris);
		}

		private string MakeJson(object value)
		{
			return JsonConvert.SerializeObject(value, _jsonSettings);
		}

		public T DeserializeJson<T>(string json)
		{
			return JsonConvert.DeserializeObject<T>(json, _jsonSettings);
		}

		private string SendHttpRequest(string method, string uri, string contentType, string data, string accessToken)
		{
			HttpMethod httpMethod = HttpMethod.Get;
			if (method.ToUpper() == "POST") httpMethod = HttpMethod.Post;

			if (httpMethod == HttpMethod.Get && !string.IsNullOrWhiteSpace(data))
			{
				uri += "?" + data;
			}
			HttpClient httpClient = new HttpClient();
			if (!string.IsNullOrWhiteSpace(accessToken))
			{
				httpClient.DefaultRequestHeaders.Add("Authorization", String.Format("Bearer {0}", accessToken));
			}
			var request = new HttpRequestMessage(httpMethod, uri);
			if (httpMethod != HttpMethod.Get && !string.IsNullOrWhiteSpace(data))
			{
				request.Content = new StringContent(data, Encoding.UTF8, contentType);
			}
			HttpResponseMessage response = httpClient.SendAsync(request).Result;
			if (!response.IsSuccessStatusCode)
			{
				string error = response.StatusCode + " " + response.ReasonPhrase;
				string content = response.Content.ReadAsStringAsync().Result;

				return "ERROR" + Environment.NewLine + "[" + method + "] " + uri + Environment.NewLine + error + Environment.NewLine + content;

				//throw new Exception("Request failed: " + error + Environment.NewLine + content);
			}
			string result = response.Content.ReadAsStringAsync().Result;
			return result;
		}

		#endregion

		private void IsUserConnectedToPartner(string accessToken, int userId)
		{
			if (string.IsNullOrWhiteSpace(accessToken))
			{
				accessToken = GetAccessToken(_exorLiveInstructorUserId);
			}

			// Use the new version 4 of the API (api4)
			string reqUri = ExorLiveAppDomain + "/api4/Access/GetUserAccessStatus";

			var data = new Dictionary<string, string>
				{
					{"applicationKey", ApplicationKey},
					{"userId", userId.ToString()}
				};
			string parameters = MakeQueryParameters(data);
			string response = SendHttpRequest("GET", reqUri, "application/json", parameters, accessToken); // Do the call
			AppendOutput("Challenge: " + response);
		}



		private void btnConnectOrg_Click(object sender, EventArgs e)
		{
			LinkLoginForm form = new LinkLoginForm();
			form.Username = "vilhelm+demo3@exorlive.com";
			form.Password = "abc";

			if (form.ShowDialog() == DialogResult.OK)
			{

				string username = form.Username;
				string password = form.Password;

				// Must authenticate as a valid administrator/instructor in the ExorLive Organization that this application has access to.
				string accessToken = GetAccessToken(_exorLiveInstructorUserId); // Authenticate as this user

				IsUserConnectedToPartner(accessToken, 12);
				IsUserConnectedToPartner(accessToken, 30);
				IsUserConnectedToPartner(accessToken, 33);
				IsUserConnectedToPartner(accessToken, 1);
				IsUserConnectedToPartner(accessToken, 3);


				// Use the new version 4 of the API (api4)
				string reqUri = ExorLiveAppDomain + "/api4/Access/PartnerChallenge";
				int random = new Random().Next();

				var data = new Dictionary<string, string>
				{
					{"ApplicationKey", ApplicationKey},
					{"Random", random.ToString()}
				};
				var json = MakeJson(data);
				string response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call
				string challenge = response;

				AppendOutput("Challenge: " + challenge);

				// Use SHA1 and salt on the password.
				string shaMacPwd = EncryptPassword(password, challenge);

				reqUri = ExorLiveAppDomain + "/api4/Access/PartnerLinkOrganizationToApplication";
				data = new Dictionary<string, string>
				{
					{"ApplicationKey", ApplicationKey},
					{"Username", username},
					{"PwdSalted", shaMacPwd},
					{"Challenge", challenge},
					{"Random", random.ToString()}
				};
				json = MakeJson(data);
				response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call
				AppendOutput("Response: " + response);
			}
		}

		public static string EncryptPassword(string password, string challenge)
		{
			SHA1 shaEngine = SHA1.Create();
			Byte[] b1 = Encoding.UTF8.GetBytes(password);
			Byte[] b2 = shaEngine.ComputeHash(b1);
			string shaPwd = ByteToHex(b2).ToLower();
			string shaMacPwd = HexHMACSha1(shaPwd, challenge);
			return shaMacPwd;
		}

		private static string HexHMACSha1(string data, string key)
		{
			System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
			byte[] keybytes = encoding.GetBytes(key);
			byte[] databytes = encoding.GetBytes(data);
			System.Security.Cryptography.HMACSHA1 hmac1 = new System.Security.Cryptography.HMACSHA1(databytes);
			System.Security.Cryptography.CryptoStream cs1 = new System.Security.Cryptography.CryptoStream(
				System.IO.Stream.Null, hmac1, System.Security.Cryptography.CryptoStreamMode.Write);
			cs1.Write(keybytes, 0, keybytes.Length);
			cs1.Close();
			byte[] result1 = hmac1.Hash;
			return ByteToHex(result1).ToUpper();
		}

		private static string ByteToHex(byte[] b)
		{
			StringBuilder converted = new StringBuilder();
			for (int i = 0; i <= b.Length - 1; i++)
			{
				string hex = Conversion.Hex(b[i]);
				if (hex.Length == 1) converted.Append("0" + hex);
				else converted.Append(hex);
			}
			return converted.ToString();
		}

		private void btnMakeSureUserHasLogin_Click(object sender, EventArgs e)
		{
			string customId = txtCustomId.Text;

			if (!string.IsNullOrWhiteSpace(customId))
			{
				// Must authenticate as a valid administrator/instructor in the ExorLive Organization that this application has access to.
				string accessToken = GetAccessToken(_exorLiveInstructorUserId); // Authenticate as this user

				// Query as the admin user, ask for a user with the given custom Id (Id used in the External Application,  called customId in ExorLive)
				var data = new Dictionary<string, string>
				{
					{"customId", customId}
				};

				var json = MakeJson(data);
				var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/MakeSureUserHasLoginAccess";
				var response = SendHttpRequest("POST", reqUri, "application/json", json, accessToken); // Do the call
				AppendOutput("Response: " + response);
			}
		}

	}
}
