﻿namespace SampleExternalAppToExorLive
{
	partial class LinkLoginForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LinkLoginForm));
			this.lblComment1 = new System.Windows.Forms.Label();
			this.txtUsername = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.lblUsername = new System.Windows.Forms.Label();
			this.lblPassword = new System.Windows.Forms.Label();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.lblHeading = new System.Windows.Forms.Label();
			this.lblComment2 = new System.Windows.Forms.Label();
			this.picExorLiveLogo = new System.Windows.Forms.PictureBox();
			this.lblSubheading = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.picExorLiveLogo)).BeginInit();
			this.SuspendLayout();
			// 
			// lblComment1
			// 
			this.lblComment1.AutoSize = true;
			this.lblComment1.Location = new System.Drawing.Point(12, 146);
			this.lblComment1.Name = "lblComment1";
			this.lblComment1.Size = new System.Drawing.Size(266, 13);
			this.lblComment1.TabIndex = 0;
			this.lblComment1.Text = "Please enter the login details of your ExorLive account.";
			// 
			// txtUsername
			// 
			this.txtUsername.Location = new System.Drawing.Point(109, 186);
			this.txtUsername.Name = "txtUsername";
			this.txtUsername.Size = new System.Drawing.Size(276, 20);
			this.txtUsername.TabIndex = 1;
			// 
			// txtPassword
			// 
			this.txtPassword.Location = new System.Drawing.Point(109, 212);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.PasswordChar = '*';
			this.txtPassword.Size = new System.Drawing.Size(276, 20);
			this.txtPassword.TabIndex = 2;
			// 
			// lblUsername
			// 
			this.lblUsername.AutoSize = true;
			this.lblUsername.Location = new System.Drawing.Point(12, 189);
			this.lblUsername.Name = "lblUsername";
			this.lblUsername.Size = new System.Drawing.Size(91, 13);
			this.lblUsername.TabIndex = 3;
			this.lblUsername.Text = "Username (email):";
			// 
			// lblPassword
			// 
			this.lblPassword.AutoSize = true;
			this.lblPassword.Location = new System.Drawing.Point(12, 215);
			this.lblPassword.Name = "lblPassword";
			this.lblPassword.Size = new System.Drawing.Size(56, 13);
			this.lblPassword.TabIndex = 4;
			this.lblPassword.Text = "Password:";
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(217, 238);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 23);
			this.btnCancel.TabIndex = 5;
			this.btnCancel.Text = "&Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.Location = new System.Drawing.Point(310, 238);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 23);
			this.btnOK.TabIndex = 6;
			this.btnOK.Text = "&OK";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// lblHeading
			// 
			this.lblHeading.AutoSize = true;
			this.lblHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblHeading.Location = new System.Drawing.Point(168, 38);
			this.lblHeading.Name = "lblHeading";
			this.lblHeading.Size = new System.Drawing.Size(145, 16);
			this.lblHeading.TabIndex = 7;
			this.lblHeading.Text = "Connect to ExorLive";
			// 
			// lblComment2
			// 
			this.lblComment2.AutoSize = true;
			this.lblComment2.Location = new System.Drawing.Point(12, 161);
			this.lblComment2.Name = "lblComment2";
			this.lblComment2.Size = new System.Drawing.Size(354, 13);
			this.lblComment2.TabIndex = 8;
			this.lblComment2.Text = "This is a one-time operation. An administration user in ExorLive is required.";
			// 
			// picExorLiveLogo
			// 
			this.picExorLiveLogo.Image = ((System.Drawing.Image)(resources.GetObject("picExorLiveLogo.Image")));
			this.picExorLiveLogo.Location = new System.Drawing.Point(12, 12);
			this.picExorLiveLogo.Name = "picExorLiveLogo";
			this.picExorLiveLogo.Size = new System.Drawing.Size(115, 123);
			this.picExorLiveLogo.TabIndex = 9;
			this.picExorLiveLogo.TabStop = false;
			// 
			// lblSubheading
			// 
			this.lblSubheading.Location = new System.Drawing.Point(168, 63);
			this.lblSubheading.Name = "lblSubheading";
			this.lblSubheading.Size = new System.Drawing.Size(198, 59);
			this.lblSubheading.TabIndex = 10;
			this.lblSubheading.Text = "Allow (this application) to connect to ExorLive on your behalf and access data of" +
    " all users in your organization.";
			// 
			// LinkLoginForm
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(403, 282);
			this.ControlBox = false;
			this.Controls.Add(this.lblSubheading);
			this.Controls.Add(this.picExorLiveLogo);
			this.Controls.Add(this.lblComment2);
			this.Controls.Add(this.lblHeading);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.lblPassword);
			this.Controls.Add(this.lblUsername);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.txtUsername);
			this.Controls.Add(this.lblComment1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "LinkLoginForm";
			this.ShowInTaskbar = false;
			this.Text = "Access to ExorLive";
			((System.ComponentModel.ISupportInitialize)(this.picExorLiveLogo)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblComment1;
		private System.Windows.Forms.TextBox txtUsername;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.Label lblUsername;
		private System.Windows.Forms.Label lblPassword;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Label lblHeading;
		private System.Windows.Forms.Label lblComment2;
		private System.Windows.Forms.PictureBox picExorLiveLogo;
		private System.Windows.Forms.Label lblSubheading;
	}
}