﻿namespace SampleExternalAppToExorLive
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.label1 = new System.Windows.Forms.Label();
			this.txtCustomId = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtFirstname = new System.Windows.Forms.TextBox();
			this.txtLastname = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.btnOpenExorLive = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.lblEmail = new System.Windows.Forms.Label();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.txtOutput = new System.Windows.Forms.TextBox();
			this.lblUserId = new System.Windows.Forms.Label();
			this.txtInstructorUserId = new System.Windows.Forms.TextBox();
			this.btnGetWorkouts = new System.Windows.Forms.Button();
			this.btnGetUsers = new System.Windows.Forms.Button();
			this.btnLookupUser = new System.Windows.Forms.Button();
			this.btnCopyWorkoutToUser = new System.Windows.Forms.Button();
			this.btnConnectOrg = new System.Windows.Forms.Button();
			this.btnOpenPersonal = new System.Windows.Forms.Button();
			this.btnDepartments = new System.Windows.Forms.Button();
			this.btnSetDisabled = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.txtUserIdForDisable = new System.Windows.Forms.TextBox();
			this.chkDisabled = new System.Windows.Forms.CheckBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.txtWorkoutId = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.btnMakeSureUserHasLogin = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(11, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(59, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Custom ID:";
			// 
			// txtCustomId
			// 
			this.txtCustomId.Location = new System.Drawing.Point(76, 19);
			this.txtCustomId.Name = "txtCustomId";
			this.txtCustomId.Size = new System.Drawing.Size(153, 20);
			this.txtCustomId.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(11, 70);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(55, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "Firstname:";
			// 
			// txtFirstname
			// 
			this.txtFirstname.Location = new System.Drawing.Point(76, 67);
			this.txtFirstname.Name = "txtFirstname";
			this.txtFirstname.Size = new System.Drawing.Size(153, 20);
			this.txtFirstname.TabIndex = 3;
			// 
			// txtLastname
			// 
			this.txtLastname.Location = new System.Drawing.Point(76, 93);
			this.txtLastname.Name = "txtLastname";
			this.txtLastname.Size = new System.Drawing.Size(153, 20);
			this.txtLastname.TabIndex = 5;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(11, 96);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "Lastname:";
			// 
			// btnOpenExorLive
			// 
			this.btnOpenExorLive.Location = new System.Drawing.Point(463, 66);
			this.btnOpenExorLive.Name = "btnOpenExorLive";
			this.btnOpenExorLive.Size = new System.Drawing.Size(149, 23);
			this.btnOpenExorLive.TabIndex = 6;
			this.btnOpenExorLive.Text = "Open &ExorLive";
			this.btnOpenExorLive.UseVisualStyleBackColor = true;
			this.btnOpenExorLive.Click += new System.EventHandler(this.btnOpenExorLive_Click);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(235, 22);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(374, 13);
			this.label4.TabIndex = 7;
			this.label4.Text = "The ID identifies this client in the External Application (this sample applicatio" +
    "n).";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(235, 70);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(251, 43);
			this.label5.TabIndex = 8;
			this.label5.Text = "Example of data about the client that will be included when creating the user in " +
    "ExorLive.";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(235, 37);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(343, 13);
			this.label7.TabIndex = 10;
			this.label7.Text = "The ID may be any unique string as defined by the External Application.";
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(467, 95);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(121, 53);
			this.label8.TabIndex = 11;
			this.label8.Text = "Will create this contact as a user in ExorLive, if not there already.";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(250, 27);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(215, 13);
			this.label9.TabIndex = 12;
			this.label9.Text = "The ExorLive user id of the active instructor.";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.lblEmail);
			this.groupBox1.Controls.Add(this.txtEmail);
			this.groupBox1.Controls.Add(this.txtCustomId);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.txtFirstname);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.txtLastname);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Location = new System.Drawing.Point(9, 190);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(562, 145);
			this.groupBox1.TabIndex = 13;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "The currently active contact";
			// 
			// lblEmail
			// 
			this.lblEmail.AutoSize = true;
			this.lblEmail.Location = new System.Drawing.Point(11, 122);
			this.lblEmail.Name = "lblEmail";
			this.lblEmail.Size = new System.Drawing.Size(35, 13);
			this.lblEmail.TabIndex = 11;
			this.lblEmail.Text = "Email:";
			// 
			// txtEmail
			// 
			this.txtEmail.Location = new System.Drawing.Point(76, 119);
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(153, 20);
			this.txtEmail.TabIndex = 12;
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.Controls.Add(this.txtOutput);
			this.groupBox2.Location = new System.Drawing.Point(9, 348);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(813, 324);
			this.groupBox2.TabIndex = 14;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Output";
			// 
			// txtOutput
			// 
			this.txtOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txtOutput.Location = new System.Drawing.Point(6, 17);
			this.txtOutput.Multiline = true;
			this.txtOutput.Name = "txtOutput";
			this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtOutput.Size = new System.Drawing.Size(801, 299);
			this.txtOutput.TabIndex = 18;
			// 
			// lblUserId
			// 
			this.lblUserId.AutoSize = true;
			this.lblUserId.Location = new System.Drawing.Point(6, 34);
			this.lblUserId.Name = "lblUserId";
			this.lblUserId.Size = new System.Drawing.Size(44, 13);
			this.lblUserId.TabIndex = 13;
			this.lblUserId.Text = "User Id:";
			// 
			// txtInstructorUserId
			// 
			this.txtInstructorUserId.Location = new System.Drawing.Point(85, 27);
			this.txtInstructorUserId.Name = "txtInstructorUserId";
			this.txtInstructorUserId.Size = new System.Drawing.Size(153, 20);
			this.txtInstructorUserId.TabIndex = 14;
			// 
			// btnGetWorkouts
			// 
			this.btnGetWorkouts.Location = new System.Drawing.Point(328, 66);
			this.btnGetWorkouts.Name = "btnGetWorkouts";
			this.btnGetWorkouts.Size = new System.Drawing.Size(129, 23);
			this.btnGetWorkouts.TabIndex = 15;
			this.btnGetWorkouts.Text = "Get &Workouts";
			this.btnGetWorkouts.UseVisualStyleBackColor = true;
			this.btnGetWorkouts.Click += new System.EventHandler(this.btnGetWorkouts_Click);
			// 
			// btnGetUsers
			// 
			this.btnGetUsers.Location = new System.Drawing.Point(169, 66);
			this.btnGetUsers.Name = "btnGetUsers";
			this.btnGetUsers.Size = new System.Drawing.Size(149, 23);
			this.btnGetUsers.TabIndex = 16;
			this.btnGetUsers.Text = "Get &Users";
			this.btnGetUsers.UseVisualStyleBackColor = true;
			this.btnGetUsers.Click += new System.EventHandler(this.btnGetUsers_Click);
			// 
			// btnLookupUser
			// 
			this.btnLookupUser.Location = new System.Drawing.Point(9, 66);
			this.btnLookupUser.Name = "btnLookupUser";
			this.btnLookupUser.Size = new System.Drawing.Size(149, 23);
			this.btnLookupUser.TabIndex = 17;
			this.btnLookupUser.Text = "&Lookup User";
			this.btnLookupUser.UseVisualStyleBackColor = true;
			this.btnLookupUser.Click += new System.EventHandler(this.btnLookupUser_Click);
			// 
			// btnCopyWorkoutToUser
			// 
			this.btnCopyWorkoutToUser.Location = new System.Drawing.Point(608, 272);
			this.btnCopyWorkoutToUser.Name = "btnCopyWorkoutToUser";
			this.btnCopyWorkoutToUser.Size = new System.Drawing.Size(179, 23);
			this.btnCopyWorkoutToUser.TabIndex = 18;
			this.btnCopyWorkoutToUser.Text = "CopyWorkoutToUser";
			this.btnCopyWorkoutToUser.UseVisualStyleBackColor = true;
			this.btnCopyWorkoutToUser.Click += new System.EventHandler(this.btnCopyWorkoutToUser_Click);
			// 
			// btnConnectOrg
			// 
			this.btnConnectOrg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnConnectOrg.Location = new System.Drawing.Point(661, 178);
			this.btnConnectOrg.Name = "btnConnectOrg";
			this.btnConnectOrg.Size = new System.Drawing.Size(126, 35);
			this.btnConnectOrg.TabIndex = 19;
			this.btnConnectOrg.Text = "Link org to app";
			this.btnConnectOrg.UseVisualStyleBackColor = true;
			this.btnConnectOrg.Click += new System.EventHandler(this.btnConnectOrg_Click);
			// 
			// btnOpenPersonal
			// 
			this.btnOpenPersonal.Location = new System.Drawing.Point(618, 66);
			this.btnOpenPersonal.Name = "btnOpenPersonal";
			this.btnOpenPersonal.Size = new System.Drawing.Size(149, 23);
			this.btnOpenPersonal.TabIndex = 20;
			this.btnOpenPersonal.Text = "Open &Mobile version";
			this.btnOpenPersonal.UseVisualStyleBackColor = true;
			this.btnOpenPersonal.Click += new System.EventHandler(this.btnOpenPersonal_Click);
			// 
			// btnDepartments
			// 
			this.btnDepartments.Location = new System.Drawing.Point(169, 95);
			this.btnDepartments.Name = "btnDepartments";
			this.btnDepartments.Size = new System.Drawing.Size(149, 23);
			this.btnDepartments.TabIndex = 21;
			this.btnDepartments.Text = "Get &Departments";
			this.btnDepartments.UseVisualStyleBackColor = true;
			this.btnDepartments.Click += new System.EventHandler(this.btnDepartments_Click);
			// 
			// btnSetDisabled
			// 
			this.btnSetDisabled.Location = new System.Drawing.Point(3, 17);
			this.btnSetDisabled.Name = "btnSetDisabled";
			this.btnSetDisabled.Size = new System.Drawing.Size(126, 23);
			this.btnSetDisabled.TabIndex = 22;
			this.btnSetDisabled.Text = "&Set User &Disabled";
			this.btnSetDisabled.UseVisualStyleBackColor = true;
			this.btnSetDisabled.Click += new System.EventHandler(this.btnSetDisabled_Click);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(2, 49);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(44, 13);
			this.label6.TabIndex = 13;
			this.label6.Text = "User-Id:";
			// 
			// txtUserIdForDisable
			// 
			this.txtUserIdForDisable.Location = new System.Drawing.Point(47, 46);
			this.txtUserIdForDisable.Name = "txtUserIdForDisable";
			this.txtUserIdForDisable.Size = new System.Drawing.Size(46, 20);
			this.txtUserIdForDisable.TabIndex = 14;
			// 
			// chkDisabled
			// 
			this.chkDisabled.AutoSize = true;
			this.chkDisabled.Location = new System.Drawing.Point(99, 48);
			this.chkDisabled.Name = "chkDisabled";
			this.chkDisabled.Size = new System.Drawing.Size(15, 14);
			this.chkDisabled.TabIndex = 23;
			this.chkDisabled.UseVisualStyleBackColor = true;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.btnSetDisabled);
			this.groupBox3.Controls.Add(this.chkDisabled);
			this.groupBox3.Controls.Add(this.txtUserIdForDisable);
			this.groupBox3.Controls.Add(this.label6);
			this.groupBox3.Location = new System.Drawing.Point(15, 95);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(143, 75);
			this.groupBox3.TabIndex = 24;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Disable/Enable user";
			// 
			// txtWorkoutId
			// 
			this.txtWorkoutId.Location = new System.Drawing.Point(675, 246);
			this.txtWorkoutId.Name = "txtWorkoutId";
			this.txtWorkoutId.Size = new System.Drawing.Size(46, 20);
			this.txtWorkoutId.TabIndex = 26;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(606, 249);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(63, 13);
			this.label10.TabIndex = 25;
			this.label10.Text = "Workout-Id:";
			// 
			// btnMakeSureUserHasLogin
			// 
			this.btnMakeSureUserHasLogin.Location = new System.Drawing.Point(564, 37);
			this.btnMakeSureUserHasLogin.Name = "btnMakeSureUserHasLogin";
			this.btnMakeSureUserHasLogin.Size = new System.Drawing.Size(203, 23);
			this.btnMakeSureUserHasLogin.TabIndex = 27;
			this.btnMakeSureUserHasLogin.Text = "Make Sure User Has Login Access";
			this.btnMakeSureUserHasLogin.UseVisualStyleBackColor = true;
			this.btnMakeSureUserHasLogin.Click += new System.EventHandler(this.btnMakeSureUserHasLogin_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(834, 684);
			this.Controls.Add(this.btnMakeSureUserHasLogin);
			this.Controls.Add(this.txtWorkoutId);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.btnDepartments);
			this.Controls.Add(this.btnOpenPersonal);
			this.Controls.Add(this.btnConnectOrg);
			this.Controls.Add(this.btnCopyWorkoutToUser);
			this.Controls.Add(this.btnLookupUser);
			this.Controls.Add(this.btnGetUsers);
			this.Controls.Add(this.btnGetWorkouts);
			this.Controls.Add(this.lblUserId);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.txtInstructorUserId);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.btnOpenExorLive);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(834, 670);
			this.Name = "MainForm";
			this.Text = "A sample \'External Application\' of ExorLive";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtCustomId;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtFirstname;
		private System.Windows.Forms.TextBox txtLastname;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnOpenExorLive;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label lblEmail;
		private System.Windows.Forms.TextBox txtEmail;
		private System.Windows.Forms.Label lblUserId;
		private System.Windows.Forms.TextBox txtInstructorUserId;
		private System.Windows.Forms.Button btnGetWorkouts;
		private System.Windows.Forms.Button btnGetUsers;
		private System.Windows.Forms.Button btnLookupUser;
		private System.Windows.Forms.TextBox txtOutput;
		private System.Windows.Forms.Button btnCopyWorkoutToUser;
		private System.Windows.Forms.Button btnConnectOrg;
		private System.Windows.Forms.Button btnOpenPersonal;
		private System.Windows.Forms.Button btnDepartments;
		private System.Windows.Forms.Button btnSetDisabled;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txtUserIdForDisable;
		private System.Windows.Forms.CheckBox chkDisabled;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.TextBox txtWorkoutId;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Button btnMakeSureUserHasLogin;
	}
}

