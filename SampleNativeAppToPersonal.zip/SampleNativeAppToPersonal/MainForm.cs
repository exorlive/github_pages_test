﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace SampleNativeAppToPersonal
{
	public partial class MainForm : Form
	{
		// The ApplicationKey and ApplicationSecret identifies the application (MRM system) that shall have access to ExorLive.
		// ExorLive is configured the know this application and what it is allowed to do.
		// The application is connected to one account (one organization) in ExorLive.
		private const String ApplicationKey = "my.application.com";
		private const string ApplicationSecret = "123456verysecretcode123456";
		readonly string _requesterDomain = HttpUtility.UrlEncode("http://my.application.no/");

		// The settings below must exactly as defined here to make the API work.
		readonly string _scope = HttpUtility.UrlEncode("read_profile read_workout read_master write_workout write_profile read_calendar read_contact admin_user create_session configure write_calendar write_contact");
		private const string Authdomain = "https://auth.exorlive.com";
		private const string ExorLiveAppDomain = "https://exorlive.com";

		private int _exorLiveAdminUserId;      // The ExorLive userId of a user in ExorLive (within the applications organization) that has access to administrate users (Administrator or Instructor role).
		private int _primaryContactId;         // The ExorLive userId of an instructor in ExorLive that will be the primary instructor (contact person) for the given client, when a new client is registered in ExorLive. This might be the same userid as _exorLiveAdminUserId.

		public MainForm()
		{
			_exorLiveAdminUserId = 1585559;
			InitializeComponent();

			// Example data for a user.
			txtMrmId.Text = @"10007";
			txtFirstname.Text = @"Arnold";
			txtLastname.Text = @"Schwarzenegger";
			txtEmail.Text = @"arnold@exorlive.com";
			_primaryContactId = 1585559;
		}

		private void btnOpenPersonal_Click(object sender, EventArgs e)
		{
			// We know the MRM-Id, so we ask ExorLive for the corresponding ExorLive userId.
			int userId = GetExorLiveUserIdFromMrmId();

			// Open ExorLive with this user logged in.
			if(userId > 0) OpenUser(userId);
		}

		/// <summary>
		/// Will query ExorLive for a user with the given MRM Id.
		/// Will create the user in ExorLive if not there already.
		/// </summary>
		/// <returns></returns>
		private int GetExorLiveUserIdFromMrmId()
		{
			if (!string.IsNullOrWhiteSpace(txtMrmId.Text))
			{
				// Must authenticate as a valid administrator/instructor in the organization that the MRM application has access to.
				string accessToken = GetAccessToken(_exorLiveAdminUserId); // Authenticate as this user

				// Query as the admin user, ask for a user with the given MRM Id (called customId in ExorLive)
				var data = new Dictionary<string, string>
				{
					{"customId", txtMrmId.Text}
				};

				// Append the access token to the request.
				var header = new Dictionary<string, string>
				{
					{"Authorization", String.Format("Bearer {0}", accessToken)}
				};
				var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/ResolveCustomId";
				var response = WebMsg(reqUri, "POST", data, "application/json; charset=utf-8", header); // Do the call

				// Parse the result.
				lblOutput.Text = response;
				var userIdHolder = JsonConvert.DeserializeObject<dynamic>(response); // Deserialize the JSON to a dynamic object
				int userId = (int)userIdHolder.d.Data;
				if (userId == 0)
				{
					// The user was not found, so we create it.
					userId = CreateUserInExorLive(accessToken);
				}
				else
				{
					GetPersonDetails(accessToken, userId);
				}
				return userId;
			}
			return 0;
		}

		private string GetAccessToken(int userId)
		{
			// This uses OAuth 2.0 conventions.

			// First get the authcode for the given user
			var data = new Dictionary<String, String>
			{
				{"user_id", userId.ToString(CultureInfo.InvariantCulture)},
				{"response_type", "code"},
				{"client_id", ApplicationKey},
				{"client_secret", ApplicationSecret},
				{"redirect_uri", _requesterDomain},
				{"scope", _scope}
			};
			var reqUri = string.Format("{0}/Providers/OAuth/Authorize.aspx", Authdomain);
			var response = WebMsg(reqUri, "GET", data, "application/x-www-form-urlencoded", null);
			var code = JsonConvert.DeserializeObject<JSonResult>(response).code; // Deserialize the JSON to an object with same structure as the JSON object.

			// Given the authcode, get the access_token.
			data = new Dictionary<string, string>
			{
				{"grant_type", "authorization_code"},
				{"client_id", ApplicationKey},
				{"client_secret", ApplicationSecret},
				{"code", code},
				{"redirect_uri", _requesterDomain}				
			};
			var tokenUrl = String.Format("{0}/Providers/OAuth/Token.ashx", Authdomain);
			response = WebMsg(tokenUrl, "POST", data, "application/x-www-form-urlencoded", null);
			var token = JsonConvert.DeserializeObject<Token>(response); // Deserialize the JSON to an object with same structure as the JSON object.
			return token.access_token;
		}
		private string RefreshToken { get; set; }
		private DateTime TokenExpiration { get; set; }
		private string RefreshAccessToken()
		{
			if ((!string.IsNullOrWhiteSpace(RefreshToken)) && TokenExpiration < DateTime.UtcNow)
			{
				string postData = String.Format("grant_type=refresh_token&client_id={0}&client_secret={1}&refresh_token={2}&redirect_uri={3}",
					ApplicationKey,
					ApplicationSecret,
					RefreshToken,
					HttpUtility.UrlEncode(_requesterDomain)
				);
				var tokenUrl = String.Format("{0}/Providers/OAuth/Token.ashx", Authdomain);
				var response = WebMsg(tokenUrl, "POST", postData, "application/x-www-form-urlencoded", null);
				try
				{
					var tokenresponse = JsonConvert.DeserializeObject<dynamic>(response); // Deserialize the JSON to an object with same structure as the JSON object.
					// Get the vital information form the JSON response.
					RefreshToken = tokenresponse.refresh_token;
					TokenExpiration = DateTime.UtcNow.AddSeconds(tokenresponse.expires_in);

					// Return the token
					return tokenresponse.access_token;
				}
				catch (ArgumentException)
				{
					// This will happen when there is invalid token data.
					RefreshToken = null;
				}
			}		
			return null;
		}

		/// <summary>
		/// Shows how the make the call to create a user in ExorLive.
		/// </summary>
		/// <param name="accessToken"></param>
		/// <returns></returns>
		private int CreateUserInExorLive(string accessToken)
		{
			var data = new
			{
				person = new
				{
					Id = 0,                           // Set to 0 to create this user in ExorLive. Set to a valid userId to update an existing user.
					CustomId = txtMrmId.Text,
					Firstname = txtFirstname.Text,
					Lastname = txtLastname.Text,
					Email = txtEmail.Text,
					IsActivated = 1,                   // Must be set to 1 to create and immediately activate this user

					Address = "",
					Location = "",
					Zipcode = "",

					Comment = "User created by MRM",  // Comment about this clients training.
					Companyname = "",           // The employer of this client.
					CultureString = "nb-NO",    // The 5-letter code for the language. Leave blank for the default language in the browser. Supported langauges are : nb-NO, sv-SE, da-DK, fi-FI, en-US
					DateOfBirth = "1947-07-30", // Leave blank, or make sure it is a valid date in the format YYYY-mm-DD
					Type = 16,                  // Leave '16', to make this user a 'client'. Set to 8 to make it an instructor.
					DepartmentId = 0,           // Use if the organization has sub-departments.
					Description = "A test-user",// Who is this person
					Height = 0,               // integer. Height in cm.
					Phone1 = "",              // Home phone number
					Phone2 = "",              // Mobile phonenumber
					Phone3 = "",              // Work phone number
					PrimaryContact = _primaryContactId,
					Sex = 1,                  // 0: unknown, 1: male, 2: female
					Web = "",                 // a URL, if the user has a webpage.
					Weight = 0,               // Weight of the user, in KG.
					WeightGoal = 0            // The Weight goal, if the goal of the client is to reduce weight.
				}
			};
			// Append the access token to the request.
			var header = new Dictionary<string, string>
				{
					{"Authorization", String.Format("Bearer {0}", accessToken)}
				};
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/SetPersonDetails"; // This call may also be used to update an existing user
			var response = WebMsg(reqUri, "POST", data, "application/json; charset=utf-8", header); // Do the call

			// Parse the result.
			lblOutput.Text = response;

			var userIdHolder = JsonConvert.DeserializeObject<dynamic>(response); // Deserialize the JSON to a dynamic object
			int userId = (int)userIdHolder.d.Data;
			return userId;
		}


		/// <summary>
		/// En example of another useful method in the API
		/// </summary>
		/// <param name="accessToken"></param>
		/// <param name="userId"></param>
		private void GetPersonDetails(string accessToken, int userId)
		{
			var data = new Dictionary<string, string>
			{
				{"personId", userId.ToString()}
			};

			// Append the access token to the request.
			var header = new Dictionary<string, string>
				{
					{"Authorization", String.Format("Bearer {0}", accessToken)}
				};
			var reqUri = ExorLiveAppDomain + "/WebServices/V1/Persons.svc/GetPersonDetails";
			var response = WebMsg(reqUri, "POST", data, "application/json; charset=utf-8", header); // Do the call

			// The result is a JSON string
			lblOutput.Text = response;
		}

		/// <summary>
		/// Will open exorlive with the specified user logged in.
		/// If the user has role "Instructor", full Exorlive web-application is opened.
		/// If the user only has role "ReducedUser" (which is the same as a client), ExorLive Personal is opened.
		/// 
		/// This will only work for a user in the organization that the ApplicationKey / ApplicationSecret is authorized for.
		/// </summary>
		/// <param name="clientUserId">the exorlive user id of the user to be logged in</param>
		private void OpenUser(int clientUserId)
		{
			string accessToken = GetAccessToken(clientUserId);

			//// Append the access_token to the URL of the authorization page. This will automatically login the user and redirect to the correct webpage for that user.
			//var uri = String.Format("{0}/?access_token={1}", Authdomain, accessToken);
			//Process.Start(uri);

			// Append the access_token to the URL of the authorization page. This will automatically login the user.
			// Tell the authorization page to redirect to the Exorlive Personal page after logged in.
			// const string redirecturi = "https://exorlive.com/m/";
			// var uri = String.Format("{0}/?access_token={1}&redirect={2}", Authdomain, accessToken, HttpUtility.UrlEncode(redirecturi));
			var uri = "https://auth.exorlive.com/?redirect=https%3A%2F%2Fexorlive.com%2Fm%2F&access_token=" + accessToken;
			Process.Start(uri);
		}

		/// <summary>
		/// A helper method for doing webrequest calls, the .NET way.
		/// </summary>
		/// <param name="uri"></param>
		/// <param name="method"></param>
		/// <param name="data"></param>
		/// <param name="contentType"></param>
		/// <param name="headers"></param>
		/// <returns></returns>
		static String WebMsg(string uri, string method, object data, string contentType, Dictionary<string, string> headers)
		{
			Dictionary<string, string> simpleData = null;
			if (data != null && data.GetType() == typeof(Dictionary<string, string>))
			{
				simpleData = (Dictionary<string, string>)data;
			}
			if (method == "GET" && simpleData != null && simpleData.Any())
			{
				var uris = (simpleData.Select(x => String.Format("{0}={1}", x.Key, x.Value))).ToList();
				uri += string.Format("?{0}", string.Join("&", uris));
			}
			var req = (HttpWebRequest)WebRequest.Create(uri);
			req.Method = method;
			if (!string.IsNullOrWhiteSpace(contentType)) { req.ContentType = contentType; }
			if (headers != null)
			{
				foreach (var keyValuePair in headers)
				{
					req.Headers.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}
			if (method == "POST")
			{
				string poststringdata = null;
				byte[] bytes = null;
				req.ContentLength = 0;
				if (simpleData != null && simpleData.Any())
				{
					if (req.ContentType != null && req.ContentType.Contains("x-www-form-urlencoded"))
					{
						poststringdata = string.Join("&", simpleData.Select(x => String.Format("{0}={1}", x.Key, x.Value)));
					}
					else
					{
						poststringdata = JsonConvert.SerializeObject(simpleData, new KeyValuePairConverter());
					}
					bytes = (new UTF8Encoding()).GetBytes(poststringdata);
				}
				if (data != null && simpleData == null)
				{
					poststringdata = JsonConvert.SerializeObject(data);
					bytes = (new UTF8Encoding()).GetBytes(poststringdata);
				}
				if (bytes != null)
				{
					req.ContentLength = bytes.Length;
					var streams = req.GetRequestStream();
					streams.Write(bytes, 0, bytes.Length);
					streams.Flush();
					streams.Close();
				}
			}
			using (var webResponse = (HttpWebResponse)req.GetResponse())
			{
				if (webResponse.StatusCode != HttpStatusCode.OK)
				{
					// Some error occurred on the server.
					using (var reader = new StreamReader(webResponse.GetResponseStream()))
					{
						string errordetails = reader.ReadToEnd();
						return errordetails;
					}
				}
				else
				{
					// Success.
					using (var reader = new StreamReader(webResponse.GetResponseStream()))
					{
						var result = reader.ReadToEnd();
						return result;
					}
				}
			}
		}

		// ReSharper disable InconsistentNaming
		struct Token
		{
			// ReSharper disable once UnassignedField.Compiler
			public string access_token;
		}

		struct JSonResult
		{

			// ReSharper disable once UnassignedField.Compiler
			public string code;
		}
		// ReSharper restore InconsistentNaming
	}
}
